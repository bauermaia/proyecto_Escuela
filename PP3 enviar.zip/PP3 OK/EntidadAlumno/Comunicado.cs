﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadAlumno
{
    public class Comunicado
    {
        public string ruta { get; set; }
        public string error { get; set; }
        public string de { get; set; }

        public string para { get; set; }

        public string asunto { get; set; }

        public DateTime fecha { get; set; }



    }
}
