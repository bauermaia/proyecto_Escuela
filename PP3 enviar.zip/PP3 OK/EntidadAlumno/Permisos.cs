﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadPermiso
{
    public class Permisos
    {
        public int id { get; set; }

        public double dni {get; set; }

        public string pass { get; set; }
        public string Desc { get; set; }

        public string estado { get; set; }


    }
}
