﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadProfesor
{
    public class profesor
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Dni { get; set; }
        public DateTime FechaNacimiento { get; set; }
        public string barrio { get; set; }
        public string calle { get; set; }
        public string altura { get; set; }
        public string edificio { get; set; }
        public string piso { get; set; }
        public string numero_dpto { get; set; }
        public string indicacion { get; set; }
        public string Telefono { get; set; }
        public string Email { get; set; }
        public string Curso { get; set; }
        public string division { get; set; }
        public string contraseña { get; set; }
        public string estado { get; set; }

    }
}