﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadAlumno
{
    public class Promedio
    {
        public string nombre { get; set; }
        public string apellido { get; set; }
        public string dni { get; set; }
        public string curso { get; set; }
        public string division { get; set; }
        public string materia { get; set; }
        public string nota { get; set; }
    }
}
