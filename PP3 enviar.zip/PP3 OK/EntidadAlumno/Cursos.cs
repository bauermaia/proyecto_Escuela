﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadAlumno
{
    public class Cursos
    {
        public string año { get; set; }
        public string division { get; set; }
        public string ciclo { get; set; }
        public string estado { get; set; }
    }
}
