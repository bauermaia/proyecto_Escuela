﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadAlumno
{
    public class boletin
    {
        public int id { get; set; }
        public string materia { get; set; }
        public string nota { get; set; }
    }
}
