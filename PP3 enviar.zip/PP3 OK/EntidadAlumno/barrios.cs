﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntidadAlumno
{
    public class barrios
    {
        public string descripcion {get;set;}
    }
}
