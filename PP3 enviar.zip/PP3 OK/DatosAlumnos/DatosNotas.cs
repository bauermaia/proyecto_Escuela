﻿using EntidadAlumno;
using EntidadNota;
using EntidadProfesor;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DatosNotas
{
    public class NotasDatos
    {
        public static List<boletin> armarboletin(string dni, int curso, int division, int ciclo)
        {
            List<boletin> boletin = new List<boletin>();
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("ArmarBoletin", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@dni", dni);
                command.Parameters.AddWithValue("@año", curso);
                command.Parameters.AddWithValue("@division", division);
                command.Parameters.AddWithValue("@ciclo", ciclo);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        boletin b = new boletin();
                        
                        b.materia = Convert.ToString(reader["materia"]);
                        b.nota = Convert.ToString(reader["nota"]);
                        
                        boletin.Add(b);
                    }

                    reader.Close();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return boletin;
        }

        public static string recuperarEtapa(DateTime fecha)
        {
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            string etapa = null;

            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("RecuperarEtapa", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@fecha", fecha);

                try
                {
                    connection.Open();
                    // Ejecutar el comando y obtener el resultado
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read()) // Si hay resultados
                    {
                        // Obtener el valor de la columna "etapa" del resultado
                        etapa = Convert.ToString(reader["etapa"]);
                    }

                    reader.Close(); // Cerrar el lector
                }
                catch (Exception)
                {
                    throw; // Manejar la excepción según sea necesario
                }
            }

            return etapa; // Devolver el valor de la etapa recuperada
        }

        public static int Eliminar(int id)
        {
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("EliminarNota", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@id", id);
                try
                {
                    connection.Open();
                    int idAlumnoCreado = Convert.ToInt32(command.ExecuteScalar());
                    connection.Close();
                }
                catch (Exception)
                {
                    throw;
                }
                return 1;
            }
        }

        public static List<string> GetMateriasxCurso(string curso, string division, int ciclo)
        {
            List<string> materias = new List<string>();
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["ConexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("GetMateriasXcurso", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@año", curso);
                command.Parameters.AddWithValue("@division", division);
                command.Parameters.AddWithValue("@ciclo", ciclo);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string denominacion = Convert.ToString(reader["Denominación"]);
                        materias.Add(denominacion);
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                return materias;

            }
        }

        public static List<string> GetEtapas()
        {
            List<string> etapas = new List<string>();
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["ConexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("GetEtapas", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string etapa = Convert.ToString(reader["etapa"]);
                        etapas.Add(etapa);
                    }
                }
                catch (Exception)
                {
                    throw;
                }
                return etapas;

            }
        }

        public static List<Nota> GetNotas(string curso, string division, string materia, string etapa, int ciclo)
        {
            List<Nota> notasLista = new List<Nota>();
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("getNotasXCurso", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@año", curso);
                command.Parameters.AddWithValue("@division", division);
                command.Parameters.AddWithValue("@materia", materia);
                command.Parameters.AddWithValue("@etapa", etapa);
                command.Parameters.AddWithValue("@ciclo", ciclo);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        Nota n = new Nota();
                        
                        n.Nombre = Convert.ToString(reader["nombre"]);
                        n.Apellido = Convert.ToString(reader["apellido"]);
                        n.Dni = Convert.ToString(reader["dni"]);
                        n.Materia= Convert.ToString(reader["materia"]);
                        n.comentario = Convert.ToString(reader["comentario"]);
                        string Calificacion = Convert.ToString(reader["Nota"]);
                        n.Calificacion = float.Parse(Calificacion);
                        DateTime fecha = (DateTime)reader["fecha"];
                        n.fecha = fecha.ToString("dd/MM/yyyy");
                        n.etapa=Convert.ToString(reader["Etapa"]);
                        notasLista.Add(n);
                    }

                    reader.Close();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return notasLista;
        }

        public static List<Nota> GetNotasDesaprobados(string curso, string division, string materia, string etapa, int ciclo)
        {
            List<Nota> notasLista = new List<Nota>();
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))
            {
                SqlCommand command = new SqlCommand("getNotasXCursoDesaprobados", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@año", curso);
                command.Parameters.AddWithValue("@division", division);
                command.Parameters.AddWithValue("@materia", materia);
                command.Parameters.AddWithValue("@etapa", etapa);
                command.Parameters.AddWithValue("@ciclo", ciclo);
                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        Nota n = new Nota();

                        n.Nombre = Convert.ToString(reader["nombre"]);
                        n.Apellido = Convert.ToString(reader["apellido"]);
                        n.Dni = Convert.ToString(reader["dni"]);
                        n.Materia = Convert.ToString(reader["materia"]);
                        n.comentario = Convert.ToString(reader["comentario"]);
                        string Calificacion = Convert.ToString(reader["Nota"]);
                        n.Calificacion = float.Parse(Calificacion);
                        DateTime fecha = (DateTime)reader["fecha"];
                        n.fecha = fecha.ToString("dd/MM/yyyy");
                        n.etapa = Convert.ToString(reader["Etapa"]);
                        notasLista.Add(n);
                    }

                    reader.Close();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return notasLista;
        }

        public static List<Nota> GetNotasXAlumno(string dni, string materia, int idProfesor, string curso, string division, int ciclo)
        {
            List<Nota> alumno = new List<Nota>();
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))

            {
                SqlCommand command = new SqlCommand("GetNotasXAlumno", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
               
                command.Parameters.AddWithValue("@dni", dni);
                command.Parameters.AddWithValue("@materia", materia);
                command.Parameters.AddWithValue("@año", curso);
                command.Parameters.AddWithValue("@division", division);
                command.Parameters.AddWithValue("@ciclo", ciclo);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        Nota n = new Nota();
                        n.Dni = Convert.ToString(reader["dni"]);
                        n.Nombre = Convert.ToString(reader["nombre"]);
                        n.Apellido = Convert.ToString(reader["apellido"]);
                        n.Materia = Convert.ToString(reader["materia"]);
                        string Calificacion = Convert.ToString(reader["Nota"]);
                        n.Calificacion = float.Parse(Calificacion);
                        n.comentario = Convert.ToString(reader["Comentario"]);
                        DateTime fecha = (DateTime)reader["fecha"];
                        n.fecha = fecha.ToString("dd/MM/yyyy");
                        n.etapa= Convert.ToString(reader["Etapa"]);

                        alumno.Add(n);
                    }

                    reader.Close();
                }
                catch (Exception)
                {
                    throw;
                }
            }
            return alumno;
        
        }

        public static List<Nota> GetNotasXdni(string dni, string v, int curso, int division, int ciclo)
        {
            List<Nota> alumno = new List<Nota>();
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString)) 
            {
                SqlCommand command = new SqlCommand("GetNotasXdni", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;

                command.Parameters.AddWithValue("@dni", dni);
                command.Parameters.AddWithValue("@Deno", v);
                command.Parameters.AddWithValue("@año", curso);
                command.Parameters.AddWithValue("@division", division);
                command.Parameters.AddWithValue("@ciclo", ciclo);

                try
                {
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();


                    while (reader.Read())
                    {
                        Nota n = new Nota();
                        n.id = Convert.ToInt16(reader["ID"]);
                        n.Dni = Convert.ToString(reader["DniAlumno"]);
                        string Calificacion = Convert.ToString(reader["Nota"]);
                        n.Calificacion = float.Parse(Calificacion);
                        n.comentario = Convert.ToString(reader["Comentario"]);
                        n.fecha = Convert.ToString(reader["fecha"]);
                        alumno.Add(n);
                    }

                    reader.Close();
                }
                catch (Exception)
                {
                    throw;
                }
                return alumno;
            }
        }

        public static int registroNotas(string materia, string alumno, string nota, int profesor, DateTime fecha, string comentario, string curso, string division, int ciclo, string etapa)
        {
            int idAlumnoCreado = 0;
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))

            {

                SqlCommand command = new SqlCommand("IngresarNotas", connection);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                float dni=Convert.ToInt64(alumno);
                command.Parameters.AddWithValue("@dni", dni);
                command.Parameters.AddWithValue("@materia", Convert.ToString(materia));
                command.Parameters.AddWithValue("@nota", Convert.ToInt32(nota));
                command.Parameters.AddWithValue("@idprofesor", (profesor));
                string fechaConvertida = fecha.ToString("dd/MM/yyyy");
                command.Parameters.AddWithValue("@fecha", fecha);
                command.Parameters.AddWithValue("@Comentario", comentario);
                command.Parameters.AddWithValue("@año", Convert.ToInt32(curso));
                command.Parameters.AddWithValue("@division", Convert.ToInt32(division));
                command.Parameters.AddWithValue("@ciclo", ciclo);
                command.Parameters.AddWithValue("@etapa", etapa);



                try
                {

                    connection.Open();
                    idAlumnoCreado = Convert.ToInt32(command.ExecuteScalar());
                    connection.Close();
                }
                catch (Exception)
                {
                    throw;
                }
                return idAlumnoCreado;
            }

        }
    }
}
