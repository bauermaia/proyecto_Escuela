﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadAlumno;
using EntidadNota;
using NegocioAlumnos;
using NotasAlumnos;
using Negocio;

using static System.Windows.Forms.VisualStyles.VisualStyleElement;

using static ProyectoEscuela.Front;

using static ProyectoEscuela.inicioSesion;
using System.Reflection.Emit;

using System.Runtime.CompilerServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

using System.Net.Mail;
using System.IO;
using System.Net;
using System.Windows.Controls.Primitives;
using System.Windows.Forms.DataVisualization.Charting;

namespace ProyectoEscuela
{
    public partial class Estadistica_desaprobados : Form
    {

        public List<Alumno> alumnos = new List<Alumno>();
        public List<Nota> lista = new List<Nota>();
        public List<Alumno> asistencias = new List<Alumno>();
       public List<string> materias = new List<string>();
        public List<string> etapas = new List<string>();
        public List<Nota> listaFiltrada = new List<Nota>();
        public Estadistica_desaprobados()
        {
            InitializeComponent();
            // encontrar la forma de recuperar en una lista las materias del curso para que se carguen en el combo box
            label4.Visible=false;
            lista = GetCursos(GlobalVariables.id);
            materias = NotasNegocio.GetMateriasxCurso("1","1",2024 );
            etapas = NotasNegocio.GetEtapas();
            int i = 0;
            int o = 0;

            i = 0;
            int a = 0;
            chart1.Titles.Add("Porcentaje de Alumnos desaprobados");


            while (i != lista.Count)
            {
                comboBox1.Items.Add("curso: " + lista[i].Curso + " Division: " + lista[i].Division + "(" + lista[i].ciclo + ")");
                
                i++;
            }
            while (o != materias.Count)
            {
                comboBox2.Items.Add(materias[o]);

                o++;
            }

            while (a != etapas.Count)
            {
                comboBox3.Items.Add(etapas[a]);

                a++;
            }
        }

        public static List<Nota> GetCursos(int id)
        {
            List<Nota> lista = new List<Nota>();
            lista = NegocioProfesor.GetPermisosPreceptor(10);


            int tam = lista.Count;
            return lista;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            buscarCurso();
        }

         private void buscarCurso()
          {
              int a = comboBox1.SelectedIndex;
              string curso = lista[a].Curso;
              string division = lista[a].Division;
              string materia = "";
              string etapa = "";
              int ciclo = GlobalVariables.ciclo;
              if (cursosGlobal.modo == 1)
              {
                  curso = cursosGlobal.curso;
                  division = cursosGlobal.division;
              }

             if (comboBox2.SelectedIndex != -1)
              {
                  materia = comboBox2.SelectedItem.ToString();


              }
              if (comboBox3.SelectedIndex != -1)
              {
                  etapa = comboBox3.SelectedItem.ToString();


              }


              seleccionarCurso(curso, division, materia, etapa, ciclo);
            int cantAlumnos = Negocio.NegocioAlumnos.cantAlumnos(lista[a].Curso, lista[a].Division, GlobalVariables.ciclo);
            int cantidadDes= listaFiltrada.Count;
            double porcentaje= (cantidadDes * 100) / cantAlumnos;
            label4.Visible = true;
            label4.Text = "Porcentaje de alumnos desaprobados: "+ porcentaje.ToString() + "%";
            chart1.Series.Clear();
            Series series = chart1.Series.Add("Alumnos");
            series.ChartType = SeriesChartType.Pie;
            series.Points.AddXY("Desaprobados", cantidadDes);
            series.Points.AddXY("Aprobados", cantAlumnos-cantidadDes);
            series.Label = "#PERCENT{P2}"; // Muestra el porcentaje
            series.LegendText = "#VALX"; // Muestra el nombre de la categoría

            // Configurar otros aspectos del gráfico
            
        }

          public void seleccionarCurso(string curso, string division, string materia, string etapa, int ciclo)
          {
              // Si materia y etapa no están seleccionadas, pasar valores nulos a la función GetNotas
              if (string.IsNullOrEmpty(materia) && string.IsNullOrEmpty(etapa))
              {

                  listaFiltrada = NotasNegocio.GetNotasDesaprobados(curso, division, null, null, ciclo);
              }
              else if (string.IsNullOrEmpty(materia))
              {

                  listaFiltrada = NotasNegocio.GetNotasDesaprobados(curso, division, null, etapa, ciclo);
              }
              else if (string.IsNullOrEmpty(etapa))
              {

                  listaFiltrada = NotasNegocio.GetNotasDesaprobados(curso, division, materia, null, ciclo);
              }
              else
              {

                  listaFiltrada = NotasNegocio.GetNotasDesaprobados(curso, division, materia, etapa, ciclo);
              }

              refreshgrid();

            
        }


          private void refreshgrid()
          {
              if (listaFiltrada.Count > 0)
              {

                  bindingSource1.DataSource = null;
                  bindingSource1.DataSource = listaFiltrada;

              }
              else
              {
                  MessageBox.Show("No se encontraron alumnos inscriptos a este curso");
              }
          }

        private void button2_Click(object sender, EventArgs e)
        {
            bindingSource1.DataSource = null;
            comboBox1.SelectedIndex = -1;
            comboBox2.SelectedIndex = -1;
            comboBox3.SelectedIndex = -1;
        }
    }
}
