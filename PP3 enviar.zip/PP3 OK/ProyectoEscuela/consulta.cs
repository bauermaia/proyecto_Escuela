﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NegocioAlumnos;
using EntidadAlumno;
using static Negocio.NegocioAlumnos;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using iTextSharp.text.pdf;
using iTextSharp.text;
using static ProyectoEscuela.inicioSesion;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using System.IO;
using NotasAlumnos;
using System.Data.SqlClient;
using EntidadNota;
using System.Net;
using System.Collections;
using Org.BouncyCastle.Asn1.X509;

namespace ProyectoEscuela
{
    public partial class consulta : Form
    {
        List<Alumno> ListaAlumnos = new List<Alumno>();
        List<Alumno> alumnoInforme = new List<Alumno>();
        List<Faltas> faltas = new List<Faltas>();
        List<boletin> boletin = new List<boletin>();
        List<Nota> lista = new List<Nota>();
        public consulta()
        {
            InitializeComponent();
           
        }

        public static class VaribalesParaConsultaParticular
        {
            public static int ciclo = 0;
            public static string dni = "";
            public static string apellido = "";
            public static string nombre = "";
            public static string año = "";
            public static string division = "";
        }
        private void mostrarAlumnos()
        {
            DataTable dt = Negocio.NegocioAlumnos.buscarinasistencias();
            dataGridView1.DataSource = dt;

        }



        

        private void button1_Click(object sender, EventArgs e)
        {
            buscar();
        }
        private void buscar() 
        {
            ListaAlumnos.Clear();
            string query = "";
            if (string.IsNullOrEmpty(txt_apellido.Text) && string.IsNullOrEmpty(txt_Nombre.Text))
            {
                query = "SELECT a.*, c.* FROM alumnos a JOIN inscripciones i ON a.dni = i.dniAlumno JOIN cursos c ON i.idCurso = c.id ORDER BY a.nombre, a.apellido ASC";
                // query = "select * from alumnos order by nombre, apellido asc"; esto trae todos, hasta los que no tienen inscripción
            }
            else
            {
                if (!string.IsNullOrEmpty(txt_apellido.Text) && !string.IsNullOrEmpty(txt_Nombre.Text))
                {
                    query = "SELECT a.*, c.* FROM alumnos a JOIN inscripciones i ON a.dni = i.dniAlumno JOIN cursos c ON i.idCurso = c.id Where nombre='"+txt_Nombre.Text+ "'and apellido = '" + txt_apellido.Text + "' ORDER BY a.nombre, a.apellido ASC";
                    //query = "select * from alumnos where nombre = '" + txt_Nombre.Text + "' and apellido = '" + txt_apellido.Text + "' order by nombre, apellido asc";
                }
                else
                {
                    if (string.IsNullOrEmpty(txt_apellido.Text))
                    {
                        query = "SELECT a.*, c.* FROM alumnos a JOIN inscripciones i ON a.dni = i.dniAlumno JOIN cursos c ON i.idCurso = c.id Where nombre = '" + txt_Nombre.Text + "' ORDER BY a.nombre, a.apellido ASC";
                        //query = "select * from alumnos where nombre = '" + txt_Nombre.Text + "' order by nombre, apellido asc";
                    }
                    else
                    {
                        query = "SELECT a.*, c.* FROM alumnos a JOIN inscripciones i ON a.dni = i.dniAlumno JOIN cursos c ON i.idCurso = c.id Where apellido = '" + txt_apellido.Text + "' ORDER BY a.nombre, a.apellido ASC";
                        //query = "select * from alumnos where apellido = '" + txt_apellido.Text + "' order by apellido, nombre asc";
                    }
                }

            }
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))

            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Alumno b = new Alumno();
                    b.Nombre = Convert.ToString(reader["nombre"]);
                    b.Dni = Convert.ToString(reader["dni"]);
                    b.Apellido = Convert.ToString(reader["apellido"]);
                    b.FechaNacimiento = Convert.ToDateTime(reader["fechaNacimiento"]);
                    b.Email = Convert.ToString(reader["email"]);
                    b.barrio = Convert.ToString(reader["barrio"]);
                    b.calle = Convert.ToString(reader["calle"]);
                    b.altura = Convert.ToString(reader["altura"]);
                    b.edificio = Convert.ToString(reader["edificio"]);
                    b.piso = Convert.ToString(reader["piso"]);
                    b.numero_dpto = Convert.ToString(reader["numero_dpto"]);
                    b.indicacion = Convert.ToString(reader["indicacion"]);
                    b.estado = Convert.ToString(reader["estado"]);
                    b.Telefono = Convert.ToString(reader["telefono"]);
                    b.Id = Convert.ToInt32(reader["id"]);
                    b.Curso = Convert.ToString(reader["año"]);
                    b.ciclo = Convert.ToInt32(reader["ciclo"]);
                    b.division = Convert.ToString(reader["division"]);
                    ListaAlumnos.Add(b);
                }
                connection.Close();
                reader.Close();
            }
            dataGridView1.DataSource = null;
            if (ListaAlumnos.Count > 0)
            {
                dataGridView1.DataSource = ListaAlumnos;

            }
        }




private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
{
    if (e.RowIndex >= 0 && e.ColumnIndex >= 0)
    {
        DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
        VaribalesParaConsultaParticular.dni = row.Cells["Dni"].Value.ToString();
        VaribalesParaConsultaParticular.apellido = row.Cells["Apellido"].Value.ToString();
        VaribalesParaConsultaParticular.nombre = row.Cells["Nombre"].Value.ToString();
        VaribalesParaConsultaParticular.año = row.Cells["Curso"].Value.ToString();
        VaribalesParaConsultaParticular.division = row.Cells["division"].Value.ToString();
        string ciclo= row.Cells["ciclo"].Value.ToString();
        VaribalesParaConsultaParticular.ciclo = Convert.ToInt32(ciclo);
        consultaAlumnoParticular formulario = new consultaAlumnoParticular();
        formulario.ShowDialog();
    }
}

        private void button2_Click(object sender, EventArgs e)
        {
            buscar2();
        }

        private void buscar2()
        {
            ListaAlumnos.Clear();
            string query = "";
            if (string.IsNullOrEmpty(txt_apellido.Text) && string.IsNullOrEmpty(txt_Nombre.Text))
            {
                
                 query = "select * from alumnos order by nombre, apellido asc"; 
            }
            else
            {
                if (!string.IsNullOrEmpty(txt_apellido.Text) && !string.IsNullOrEmpty(txt_Nombre.Text))
                {
                
                    query = "select * from alumnos where nombre = '" + txt_Nombre.Text + "' and apellido = '" + txt_apellido.Text + "' order by nombre, apellido asc";
                }
                else
                {
                    if (string.IsNullOrEmpty(txt_apellido.Text))
                    {
                    
                    query = "select * from alumnos where nombre = '" + txt_Nombre.Text + "' order by nombre, apellido asc";
                    }
                    else
                    {
                    
                        query = "select * from alumnos where apellido = '" + txt_apellido.Text + "' order by apellido, nombre asc";
                    }
                }

            }
            string conString = System.Configuration.ConfigurationManager.ConnectionStrings["conexionDB"].ConnectionString;
            using (SqlConnection connection = new SqlConnection(conString))

            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Alumno b = new Alumno();
                    b.Nombre = Convert.ToString(reader["nombre"]);
                    b.Dni = Convert.ToString(reader["dni"]);
                    b.Apellido = Convert.ToString(reader["apellido"]);
                    b.FechaNacimiento = Convert.ToDateTime(reader["fechaNacimiento"]);
                    b.Email = Convert.ToString(reader["email"]);
                    b.barrio = Convert.ToString(reader["barrio"]);
                    b.calle = Convert.ToString(reader["calle"]);
                    b.altura = Convert.ToString(reader["altura"]);
                    b.edificio = Convert.ToString(reader["edificio"]);
                    b.piso = Convert.ToString(reader["piso"]);
                    b.numero_dpto = Convert.ToString(reader["numero_dpto"]);
                    b.indicacion = Convert.ToString(reader["indicacion"]);
                    b.estado = Convert.ToString(reader["estado"]);
                    b.Telefono = Convert.ToString(reader["telefono"]);
                    b.Id = Convert.ToInt32(reader["id"]);                    
                    ListaAlumnos.Add(b);
                }
                connection.Close();
                reader.Close();
            }
            dataGridView1.DataSource = null;
            if (ListaAlumnos.Count > 0)
            {
                dataGridView1.DataSource = ListaAlumnos;

            }
        }
    }
}
