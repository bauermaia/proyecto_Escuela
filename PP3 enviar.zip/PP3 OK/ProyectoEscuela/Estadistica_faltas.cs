﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using EntidadAlumno;
using EntidadNota;
using NegocioAlumnos;
using NotasAlumnos;
using Negocio;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

using static ProyectoEscuela.Front;

using static ProyectoEscuela.inicioSesion;
using System.Reflection.Emit;

using System.Runtime.CompilerServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

using System.Net.Mail;
using System.IO;
using System.Net;
using System.Windows.Forms.DataVisualization.Charting;


namespace ProyectoEscuela
{
    public partial class Estadistica_faltas : Form
    {
        int cantFaltas = 0;
        double porcentaje = 0;
        public List<Alumno> alumnos = new List<Alumno>();
        public List<Faltas> faltas = new List<Faltas>();
        public List<Nota> lista = new List<Nota>();
        public List<Alumno> asistencias = new List<Alumno>();
        
        public Estadistica_faltas()
        {

            InitializeComponent();
            label2.Visible=false;
            lista = GetCursos(GlobalVariables.id);
            int i = 0;
            int o = 1;

            i = 0;
            o = 1;

            chart1.Titles.Add("Porcentaje de Alumnos que Superan Faltas");



            while (i != lista.Count)
            {
                comboBox1.Items.Add("curso: " + lista[i].Curso + " Division: " + lista[i].Division + "(" + lista[i].ciclo + ")");
                i++;
            }

        }

        public static List<Nota> GetCursos(int id)
        {
            List<Nota> lista = new List<Nota>();
           lista = NegocioProfesor.GetPermisosPreceptor(10);
            
            
            int tam = lista.Count;
            return lista;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            cantFaltas = Convert.ToInt32(textBox1.Text);
            int a = comboBox1.SelectedIndex;
            int cantAlumnos = Negocio.NegocioAlumnos.cantAlumnos(lista[a].Curso , lista[a].Division , GlobalVariables.ciclo);
            int superan = Negocio.NegocioAlumnos.superanFaltas(cantFaltas, lista[a].Curso, lista[a].Division, GlobalVariables.ciclo);
            porcentaje = (superan * 100) / cantAlumnos;
            int nosup= cantAlumnos-superan;
            label2.Visible = true;
            label2.Text ="Porcentaje de estudiantes con mas de "+textBox1.Text+" faltas: "+ porcentaje.ToString()+"%";
            alumnos = Negocio.NegocioAlumnos.GetXCantFaltas(cantFaltas, lista[a].Curso, lista[a].Division, GlobalVariables.ciclo);
          bindingSource1.DataSource = null;
            bindingSource1.DataSource = alumnos;
           //
            chart1.Series.Clear();
            Series series = chart1.Series.Add("Alumnos");
            series.ChartType = SeriesChartType.Pie;
            series.Points.AddXY("Superan Faltas", superan);
            series.Points.AddXY("No Superan Faltas", nosup);
            series.Label = "#PERCENT{P2}"; // Muestra el porcentaje
            series.LegendText = "#VALX"; // Muestra el nombre de la categoría

            // Configurar otros aspectos del gráfico
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            buscarCurso();
        }

        private void buscarCurso()
        {
            int a = comboBox1.SelectedIndex;
            string curso = lista[a].Curso;
            string division = lista[a].Division;
            if (cursosGlobal.modo == 1)
            {
                curso = cursosGlobal.curso;
                division = cursosGlobal.division;
            }
            
            seleccionarCurso(curso, division);
        }

        public void seleccionarCurso(string curso, string division)
        {
            alumnos = Negocio.NegocioAlumnos.GetXCurso("", curso, division, GlobalVariables.ciclo);
            int i = 0;
            float contador = 0;
            while (i < alumnos.Count)
            {

                faltas = Negocio.NegocioAlumnos.BuscarFaltas(alumnos[i].Dni, lista[comboBox1.SelectedIndex].ciclo, lista[comboBox1.SelectedIndex].Curso, division);
                contador = helpers.ConvertirFaltas.conversion(faltas);
                i++;
            }
            asistencias = Negocio.NegocioAlumnos.TraerAsistenciasDeHoy(curso, division, DateTime.Now, GlobalVariables.ciclo);
            refreshgrid();
        }

        private void refreshgrid()
        {
            if (alumnos.Count > 0)
            {
                
                bindingSource1.DataSource = null;
                bindingSource1.DataSource = alumnos;
               
            }
            else
            {
                MessageBox.Show("No se encontraron alumnos inscriptos a este curso");
            }
        }
    }
}
