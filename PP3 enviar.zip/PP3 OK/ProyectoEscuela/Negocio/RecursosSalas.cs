﻿namespace Negocio
{
    internal class RecursosSalas
    {
    }
}